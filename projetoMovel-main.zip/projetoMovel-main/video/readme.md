Gravar um video com a apresentação do projeto com duração de até 10 minutos
