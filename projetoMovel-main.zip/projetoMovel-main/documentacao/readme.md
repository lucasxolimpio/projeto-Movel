# Modelos dos documentos necessários na elaboração do projeto

Para a entrega final do projeto, os modelos aqui compartilhados devem estar preenchidos, sem quaisquer comentário ou marcações no documento

- Entregar cada um dos documentos no formato .DOCX e .PDF
- Entregar um arquivo único em .PDF com todos os documentos agrupados
- Assinatura digital dos documentos utilizando a plataforma .GOV.BR (assinatura digital gratuita)
