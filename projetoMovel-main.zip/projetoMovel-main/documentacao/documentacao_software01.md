<a id="inicio"></a>

Green Keeper: Diário de Plantas e Lembretes de Rega

Documentação Técnica e Acadêmica do Projeto de Programação de Dispositivos Móveis

1. Visão Geral e Problemática

2. Arquitetura Técnica (React Native e Firebase)

3. Implementação do Recurso Nativo (Notificações)

4. Ferramentas e Dependências

5. Conclusão e Aprendizado

<a id="topico1"></a>

1. Visão Geral e Problemática <a href="#inicio" title="Retorna ao inicio do documento">^</a>

O projeto Green Keeper visa solucionar a problemática da perda de plantas domésticas devido à rega inadequada (falta ou excesso), comum em rotinas urbanas atarefadas. O objetivo é fornecer uma ferramenta digital centralizada que atue como um "diário" e um assistente ativo de cuidados.

Justificativa: A solução se baseia na aplicação prática de competências de desenvolvimento cross-platform (React Native/Expo), integrando persistência de dados em tempo real (Firebase Firestore) e o uso estratégico de recursos nativos (Notificações) para combater o esquecimento.

O aplicativo atende aos seguintes objetivos:

Permitir o CRUD (cadastro, listagem, edição e exclusão) de plantas.

Implementar um sistema de reagendamento automático e de lembretes por notificações.

2. Arquitetura Técnica (React Native e Firebase) <a href="#inicio" title="Retorna ao inicio do documento">^</a>

A solução foi desenvolvida como um aplicativo móvel utilizando React Native/Expo para o Frontend, garantindo portabilidade entre Android e iOS. A persistência de dados é gerenciada pelo Firebase Firestore.

2.1. Estrutura de Dados e CRUD

Os dados são armazenados na coleção privada: /artifacts/{__app_id}/users/{userId}/plants. Cada documento (planta) contém campos essenciais para o agendamento de rega:
Campo

Campo                       Tipo                Descrição    
     
name                       string              Nome da planta.

waterIntervalDays          number              Intervalo de rega (em dias).

lastWatered                timestamp           Última data de rega registrada.

nextWatering               timestamp           Próxima data de rega calculada. (Crucial para a notificação)

A listagem de plantas (HomeScreen) utiliza a função onSnapshot do Firestore, garantindo que a lista seja atualizada em tempo real sempre que um usuário registra uma rega em outro dispositivo ou na tela de detalhes.

01   // Exemplo de trecho da lógica de READ/UPDATE
02   const q = query(plantsCollectionRef);
03   const unsubscribe = onSnapshot(q, (snapshot) => {
04     // Atualiza o estado das plantas em tempo real
05     // ...
06   });
07   
08   const handleRegar = async () => {
09       // 1. Atualiza a data da última rega
10       // 2. Calcula a nova data de próxima rega (lastWatered + waterIntervalDays)
11       // 3. Chama a função nativa de notificação: scheduleWateringNotification(...)
12   };


3. Implementação do Recurso Nativo (Notificações) <a href="#inicio" title="Retorna ao inicio do documento">^</a>

O principal recurso nativo é o agendamento de Notificações Push (utilizando expo-notifications no ambiente real, simulado no código web). Esta ação é ativada em dois momentos: no CREATE de uma nova planta e no UPDATE da ação "REGAR AGORA".

O recurso nativo é essencial para a "Teoria da Interrupção Produtiva" (Referencial Teórico), pois garante que o aplicativo interrompa o usuário com um lembrete relevante (a rega) fora do contexto de uso do próprio aplicativo, combatendo eficazmente o esquecimento.

O agendamento é feito com base no campo nextWatering (calculado a partir de lastWatered e waterIntervalDays), assegurando que a notificação ocorra na data exata.

4. Ferramentas e Dependências <a href="#inicio" title="Retorna ao inicio do documento">^</a>

O projeto foi desenvolvido com as seguintes ferramentas e tecnologias:

Categoria              Tecnologia                  Uso

Framework Mobile        React Native/Expo           Desenvolvimento cross-platform da interface.

Banco de Dados          Firebase Firestore          Persistência de dados em nuvem, CRUD e sincronização em tempo real.

Navegação               React Navigation            Gerenciamento do fluxo de telas (Home, Novo Item, Detalhes).

Recursos Nativos        expo-notifications          Implementação do lembrete de rega (Recurso Nativo).

Ambiente de Trabalho    VS Code                     Edição e desenvolvimento do código-fonte.

<a id="conclusao"></a>

5. Conclusão e Aprendizado <a href="#inicio" title="Retorna ao inicio do documento"  style="text-decoration: none;">^</a>

O projeto Green Keeper atingiu seus objetivos sociocomunitários e acadêmicos. O desenvolvimento da solução comprovou a viabilidade e a eficiência da arquitetura React Native + Firebase para a criação de aplicativos funcionais com persistência robusta em um curto espaço de tempo.

A principal aprendizagem reside na integração bem-sucedida entre a manipulação de dados em tempo real (Firestore) e o uso estratégico de um Recurso Nativo (Notificações) para resolver uma demanda real do público. Este projeto forneceu uma experiência prática em desenvolvimento full-stack móvel, indo além da interface e tocando em temas críticos como persistência de dados e experiência do usuário (UX).
