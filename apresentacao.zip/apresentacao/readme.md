Nesta pasta o grupo deve salvar a apresentação .PPT .PPTX e .PDF

A apresentação será realizada em até 10 minutos por grupo

A quantidade de slides deve ao menos conter:
- Tema do projeto, dados do grupo (matrícula, nome completo dos participantes) e orientador: Prof. Luiz Gustavo Turatti
- Indice
- Cronograma
- Objetivo
- Telas do aplicativo
